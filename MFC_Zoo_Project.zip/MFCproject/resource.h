//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by zooTestOne.rc
//
#define IDD_ZOOTESTONE_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDC_ANIMAL_LIST                 1000
#define IDC_Fish                        1001
#define IDC_DOG                         1002
#define IDC_SIAMI_C                     1003
#define IDC_STREET_C                    1004
#define IDC_ANIMAL_TYPE                 1005
#define IDC_ED_NAME                     1006
#define IDC_NAME                        1007
#define IDC_AGE                         1008
#define IDC_ED_AGE                      1009
#define IDC_BTN_DEL                     1012
#define IDC_BUTTON2                     1013
#define IDC_BTN_ADD                     1013
#define IDC_BTN_UNDO                    1014
#define IDC_BUTTON3                     1015
#define IDC_BTN_REDO                    1015
#define IDC_BTN_SAVE                    1016
#define IDC_BUTTON4                     1017
#define IDC_BTN_OPEN                    1017
#define IDC_RADIO1                      1018
#define IDC_RADIO2                      1019
#define IDC_RADIO3                      1020
#define IDC_RADIO4                      1021
#define IDC_RADIO5                      1022
#define IDC_RADIO6                      1023
#define IDC_RADIO7                      1024
#define IDC_RADIO8                      1025
#define IDC_RADIO9                      1026
#define IDC_RADIO10                     1027
#define IDC_RADIO11                     1028
#define IDC_BUTTON1                     1034
#define IDC_BUTTON5                     1035
#define IDC_BUTTON6                     1036
#define IDC_BUTTON7                     1037
#define IDC_BUTTON8                     1038
#define IDC_BUTTON9                     1039
#define IDC_BUTTON10                    1040
#define IDC_BUTTON11                    1041
#define IDC_BUTTON12                    1042
#define IDC_BUTTON13                    1043
#define IDC_BUTTON14                    1044

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1045
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
